package com.example.demo.mercantile;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * A geographic bounding box
 * Attributes
 * ----------
 * west, south, east, north : float
 *     Bounding values in decimal degrees.
 */
@Data
@AllArgsConstructor
public class LngLatBbox {
    private double west;
    private double south;
    private double east;
    private double north;
}
