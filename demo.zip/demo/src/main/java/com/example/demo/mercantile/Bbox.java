package com.example.demo.mercantile;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * A web mercator bounding box
 * Attributes
 * ----------
 * left, bottom, right, top : float
 *     Bounding values in meters.
 */
@Data
@AllArgsConstructor
public class Bbox {
    private double left;
    private double bottom;
    private double right;
    private double top;

}
