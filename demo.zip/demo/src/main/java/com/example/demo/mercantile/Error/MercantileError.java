package com.example.demo.mercantile.Error;

public class MercantileError extends Exception {
}
