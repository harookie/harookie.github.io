package com.example.demo.mercantile.Error;

public class TileError extends MercantileError {
}
