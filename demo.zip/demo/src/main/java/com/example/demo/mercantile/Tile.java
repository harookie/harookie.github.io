package com.example.demo.mercantile;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * An XYZ web mercator tile
 * Attributes
 * ----------
 * x, y, z : int
 *     x and y indexes of the tile and zoom level z.
 */
@Data
@AllArgsConstructor
public class Tile {
    private int x;
    private int y;
    private int z;
}
