package com.example.demo.mercantile;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class XY {
    private double x;
    private double y;
}
