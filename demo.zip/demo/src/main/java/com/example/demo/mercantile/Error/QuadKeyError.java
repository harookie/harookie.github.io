package com.example.demo.mercantile.Error;

public class QuadKeyError extends MercantileError {
}
