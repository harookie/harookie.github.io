package com.example.demo.mercantile.Error;

public class InvalidZoomError extends MercantileError {
}
