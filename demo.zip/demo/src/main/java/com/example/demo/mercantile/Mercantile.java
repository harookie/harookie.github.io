package com.example.demo.mercantile;

import java.util.ArrayList;
import java.util.List;

public class Mercantile {
    public static final double R2D = 180 / Math.PI;
    public static final double RE = 6378137.0;
    public static final double CE = 2 * Math.PI * RE;
    public static final double EPSILON = 1e-14;
    public static final double LL_EPSILON = 1e-11;

    /**
     * Returns the upper left longitude and latitude of a tile
     *     Examples
     *     --------
     *     >>> ul(Tile(x=0, y=0, z=1))
     *     LngLat(lng=-180.0, lat=85.0511287798066)
     *     >>> mercantile.ul(1, 1, 1)
     *     LngLat(lng=0.0, lat=0.0)
     * @param tile Tile or sequence of int
     *             May be be either an instance of Tile or 3 ints, X, Y, Z.
     * @return LngLat
     */
    public LngLat ul(Tile tile) {
        double Z2 = Math.pow(2, tile.getZ());
        double lon_deg = tile.getX() / Z2 * 360.0 - 180.0;
        double lat_rad = Math.atan(Math.sinh(Math.PI * (1 - 2 * tile.getY() / Z2)));
        double lat_deg = Math.toDegrees(lat_rad);
        return new LngLat(lon_deg, lat_deg);
    }

    /**
     * Returns the bounding box of a tile
     *     Notes
     *     -----
     *     Epsilon is subtracted from the right limit and added to the bottom limit.
     * @param tile Tile or sequence of int May be be either an instance of Tile or 3 ints, X, Y, Z.
     * @return LngLatBBox
     */
    public LngLatBbox bounds(Tile tile) {
        LngLat a = ul(tile);
        LngLat b = ul(new Tile(tile.getX() + 1, tile.getY() + 1, tile.getZ()));
        return new LngLatBbox(a.getLng(), b.getLat(), b.getLng(), a.getLat());
    }

    private LngLat truncate_lnglat(LngLat lnglat) {
        double lng = lnglat.getLng();
        double lat = lnglat.getLat();

        if (lng > 180.0) {
            lng = 180.0;
        } else if (lng < -180.0) {
            lng = -180.0;
        } else if (lat > 90.0) {
            lat = 90.0;
        } else if (lat < -90.0) {
            lat = -90.0;
        }

        return new LngLat(lng, lat);
    }

    /**
     * Convert longitude and latitude to web mercator x, y
     * @param lnglat Longitude and latitude in decimal degrees.
     * @param truncate Whether to truncate or clip inputs to web mercator limits.
     * @return XY y will be inf at the North Pole (lat >= 90) and -inf at the
     * South Pole (lat <= -90).
     */
    private XY xy(LngLat lnglat, boolean truncate) {
        if (truncate) {
            lnglat = truncate_lnglat(lnglat);
        }

        double x = RE * Math.toRadians(lnglat.getLng());
        double y;

        if (lnglat.getLng() <= -90) {
            y = Double.NEGATIVE_INFINITY;
        } else if (lnglat.getLat() >= 90) {
            y = Double.POSITIVE_INFINITY;
        } else {
            y = RE * Math.log(Math.tan((Math.PI * 0.25) + (0.5 * Math.toRadians(lnglat.getLat()))));
        }

        return new XY(x, y);
    }

    private XY xy(LngLat lnglat) {
        return xy(lnglat, false);
    }

    /**
     * Convert web mercator x, y to longitude and latitude
     * @param xy web mercator coordinates in meters.
     * @param truncate Whether to truncate or clip inputs to web mercator limits.
     * @return LngLat
     */
    public LngLat lnglat(XY xy, boolean truncate) {
        double lng = xy.getX() * R2D / RE;
        double lat = ((Math.PI * 0.5) - 2.0 * Math.atan(Math.exp(-xy.getY() / RE))) * R2D;

        LngLat lnglat = new LngLat(lng, lat);

        if (truncate) {
            lnglat = truncate_lnglat(lnglat);
        }

        return lnglat;
    }

    public LngLat lnglat(XY xy) {
        return lnglat(xy, false);
    }

    /**
     * Get the web mercator bounding box of a tile
     *     Notes
     *     -----
     *     Epsilon is subtracted from the right limit and added to the bottom
     *     limit.
     * @param tile May be be either an instance of Tile or 3 ints, X, Y, Z.
     * @return Bbox
     */
    public Bbox xy_bounds(Tile tile) {
        double tile_size = CE / Math.pow(2, tile.getZ());

        double left = tile.getX() * tile_size - CE / 2;
        double right = left + tile_size;

        double top = CE / 2 - tile.getY() * tile_size;
        double bottom = top - tile_size;

        return new Bbox(left, bottom, right, top);
    }

    private XY _xy(LngLat lnglat) {
        return _xy(lnglat, false);
    }

    private XY _xy(LngLat lnglat, boolean truncate) {
        if (truncate) {
            lnglat = truncate_lnglat(lnglat);
        }

        double x = lnglat.getLng() / 360.0 + 0.5;
        double y;
        double sinlat = Math.sin(Math.toRadians(lnglat.getLat()));

        // todo : add Exception
        y = 0.5 - 0.25 * Math.log((1.0 + sinlat) / (1.0 - sinlat)) / Math.PI;

        return new XY(x, y);
    }

    /**
     *     """Get the tile containing a longitude and latitude
     * @param lnglat A longitude and latitude pair in decimal degrees.
     * @param zoom The web mercator zoom level.
     * @param truncate Whether or not to truncate inputs to limits of web mercator.
     * @return Tile
     */
    public Tile tile(LngLat lnglat, int zoom, boolean truncate) {
        XY xy = _xy(lnglat, truncate = truncate);
        double Z2 = Math.pow(2, zoom);

        int xtile = 0;
        int ytile = 0;

        if (xy.getX() <= 0) {
            xtile = 0;
        } else if (xy.getX() >= 1) {
            xtile = Integer.parseInt(String.valueOf(Math.round(Z2 - 1)));
        }
        else
//            To address loss of precision in round-tripping between tile
//            and lng/lat, points within EPSILON of the right side of a tile
//            are counted in the next tile over.
        {
            Integer.parseInt(String.valueOf(Math.floor((xy.getX() + EPSILON) * Z2)));
        }

        if (xy.getY() <= 0) {
            ytile = 0;
        }
        else if (xy.getY() >= 1) {
            ytile = Integer.parseInt(String.valueOf(Math.round(Z2 - 1)));
        }
        else {
            ytile = Integer.parseInt(String.valueOf(Math.floor((xy.getY() + EPSILON) * Z2)));
        }

        return new Tile(xtile, ytile, zoom);
    }

    public Tile tile(LngLat lnglat, int zoom) {
        return tile(lnglat, zoom, false);
    }

    /**
     * Get the quadkey of a tile
     * @param tile May be be either an instance of Tile or 3 ints, X, Y, Z.
     * @return String
     */
    public static String quadkey(Tile tile) {
        List<String> qk = new ArrayList<>();

        int digit, mask;
        for (int z = tile.getZ(); z > 0; z--) {
            digit = 0;
            mask = 1 << (z - 1);
            // todo : check below line
            if ((tile.getX() & mask) != 0) {
                digit += 1;
            }
            if ((tile.getY() & mask) != 0) {
                digit += 2;
            }
            qk.add(Integer.toString(digit));
        }

        return String.join("", qk);
    }

    /**
     * Get the tile corresponding to a quadkey
     * @param qk A quadkey string.
     * @return Tile
     */
    public static Tile quadkey_to_tile(String qk) {
        if (qk.length() == 0) {
            return new Tile(0, 0, 0);
        }

        int xtile = 0;
        int ytile = 0;

        char digit;
        int mask;
        for (int i = 0; i < qk.length(); i++) {
            // get char in reverse order
            digit = qk.charAt(qk.length() - i - 1);
            mask = 1 << i;

            if (digit == '1') {
                xtile = xtile | mask;
            } else if (digit == '2') {
                ytile = ytile | mask;
            } else if (digit == '3') {
                xtile = xtile | mask;
                ytile = ytile | mask;
            }
            // todo : add exception
        }

        return new Tile(xtile, ytile, qk.length());
    }

    public static ()
    def tiles(west, south, east, north, zooms, truncate=False):
}
