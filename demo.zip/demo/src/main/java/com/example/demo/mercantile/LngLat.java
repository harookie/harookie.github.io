package com.example.demo.mercantile;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * A longitude and latitude pair
 * Attributes
 * ----------
 * lng, lat : float
 *     Longitude and latitude in decimal degrees east or north.
 */
@Data
@AllArgsConstructor
public class LngLat {
    private double lng;
    private double lat;
}
